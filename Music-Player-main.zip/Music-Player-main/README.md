# Music-Player with JavaScript

Function
1) Random Song
2) Previous Song
3) Next Song
4) Repeat Song

The Layout Design of Music Player
![Screenshot 2023-02-01 110931](https://user-images.githubusercontent.com/86345777/215935830-07cfc994-c4f7-421c-91c5-f2ad7a0d42d4.png)
